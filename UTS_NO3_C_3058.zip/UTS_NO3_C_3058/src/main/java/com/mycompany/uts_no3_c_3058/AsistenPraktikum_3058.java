/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no3_c_3058;

/**
 *
 * @author badnoby
 */
public class AsistenPraktikum_3058 extends Mahasiswa_3058 {
    String mkAsisten_3058;
    int jmlPertemuan_3058;
    
    public double totalPendapatan_3058(){
        return(jmlPertemuan_3058 * 50000);
    }
    public void tampilDataAsistenPraktikum_3058() {
        super.tampilDataMhs_3058();
        System.out.println(" Mata Kuliah    : " + mkAsisten_3058);
        System.out.println(" Jumlah Pertemuan   : " + jmlPertemuan_3058);
        System.out.println(" Total Pendapatan : " + totalPendapatan_3058());
        
        
    }
}
